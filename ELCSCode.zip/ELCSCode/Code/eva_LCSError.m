
function [nundirected,nreverse,nmiss,nextra,ntotal]=eva_LCSError(G,DAG)
    diff_G=G-DAG;
    [x,y]=find(diff_G~=0);

    nundirected=0;
    nreverse=0;
    nmiss=0;
    nextra=0;
    ntotal=0;
    for loop = 1 : length(x)
        %two case : G=-1,DAG=0 or G=0,DAG=1
        if diff_G(x(loop),y(loop)) == -3 
            continue;
        end
        if diff_G(x(loop),y(loop)) == -1
            if G(x(loop),y(loop))==-1 
                if DAG(y(loop),x(loop))==-1
                    nreverse = nreverse + 1;
                    diff_G(y(loop),x(loop)) = -3;
                elseif DAG(y(loop),x(loop))==0
                    nmiss = nmiss + 1;
                end
            elseif G(x(loop),y(loop))==0
                if  G(y(loop),x(loop))==-1&&DAG(y(loop),x(loop))==1
                     nundirected = nundirected + 1;
                     diff_G(y(loop),x(loop)) = -3;
                else
                    nextra = nextra + 1;
                end
            end
        elseif diff_G(x(loop),y(loop)) == -2
            if  G(y(loop),x(loop))==0&&DAG(y(loop),x(loop))==1
                nundirected = nundirected + 1;
                diff_G(y(loop),x(loop)) = -3;
            end
        elseif diff_G(x(loop),y(loop)) == 1
            if G(y(loop),x(loop))==-1&&DAG(y(loop),x(loop))==0
                nreverse = nreverse + 1;
                diff_G(y(loop),x(loop)) = -3;
            else
                nextra = nextra + 1;
            end
        end
    end
    ntotal=nextra+nmiss+nreverse+nundirected;
end



