
function [precision,recall,distance,F1,FDR]=eva_ArrhdPR(trueC,C,trueP,P)
    if isempty(trueC)&&isempty(trueP)
        if isempty(C)&&isempty(P)
            precision=1;
            recall=1;
            distance=0;
            F1=1;
        else
            precision=0;
            recall=0;
            distance=sqrt(2);
            F1=0;
        end
    else
        if ~isempty(C)||~isempty(P)
            precision1=(length(intersect(trueC,C))+length(intersect(trueP,P))+1)/(length(C)+length(P)+1);
            recall1=(length(intersect(trueC,C))+length(intersect(trueP,P)))/(length(trueC)+length(trueP));
            distance1=sqrt((1-recall1)*(1-recall1)+(1-precision1)*(1-precision1));
            if (precision1+recall1)==0
                f1=0;
            else
                f1=2*precision1*recall1/(precision1+recall1);
            end
            precision=precision1;
            recall=recall1;
            distance=distance1;
            F1=f1;
        else
            precision=0;
            recall=0;
            distance=sqrt(2);
            F1=0;
        end
    end
end


