
The codes of the ELCS algorithm of the paper titled with "Towards Efficient Local Causal Structure Learning"
and are implemented in MATLAB 

Shuai Yang, Hao Wang, Kui Yu, Fuyan Cao, and Xindong Wu. Towards Efficient Local Causal Structure Learning.  IEEE Transactions on Big Data.  10.1109/TBDATA.2021.3062937, 2021.


Note:

In the current package,  the .p files are from the CausalExplorer_1.4 package and they are only implemented in MATLAB2014a. 

For the avanced versions of MATLAB, please using these .p files in CausalExplorer_1.5 which are avaiable at

https://github.com/mensxmachina/CausalExplorer_1.5




















